package com.hospital.dashboard.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * A small, generic JdbcTemplate helper used for the 11 "supporting" tables
 * (phone numbers, qualifications, ratings, specializations, feedback,
 * medical records, and the many-to-many link tables). These tables are
 * simple enough (a handful of columns, no complex business rules) that
 * writing a full Model + Repository + Service class for each one would be
 * pure boilerplate for a DBMS course project. Rows are passed around as
 * plain Map<String, Object>, where each map key IS the exact Oracle column
 * name - so, unlike the core entities, there is no camelCase <-> snake_case
 * translation here.
 *
 * This still goes through JdbcTemplate with bound parameters (never string
 * concatenation), so it is just as safe from SQL injection as the typed
 * repositories.
 */
@Repository
public class GenericTableRepository {

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedJdbcTemplate;

    public GenericTableRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.namedJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
    }

    public List<Map<String, Object>> findAll(String table) {
        return jdbcTemplate.queryForList("SELECT * FROM " + table);
    }

    public List<Map<String, Object>> findByColumn(String table, String column, Object value) {
        return jdbcTemplate.queryForList("SELECT * FROM " + table + " WHERE " + column + " = ?", value);
    }

    public Map<String, Object> findOneByColumn(String table, String column, Object value) {
        List<Map<String, Object>> rows = findByColumn(table, column, value);
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * Inserts a row. If idColumn is non-null it is treated as an auto-generated
     * primary key (excluded from the INSERT and populated in the returned map
     * from the generated key). If idColumn is null (composite-key link table),
     * every entry in "data" is inserted as given.
     */
    public Map<String, Object> insert(String table, String idColumn, Map<String, Object> data) {
        Map<String, Object> columns = new LinkedHashMap<>(data);
        if (idColumn != null) {
            columns.remove(idColumn);
        }
        String columnList = String.join(", ", columns.keySet());
        String placeholders = columns.keySet().stream().map(c -> ":" + c).collect(Collectors.joining(", "));
        String sql = "INSERT INTO " + table + " (" + columnList + ") VALUES (" + placeholders + ")";

        MapSqlParameterSource params = new MapSqlParameterSource(columns);

        if (idColumn != null) {
            KeyHolder keyHolder = new GeneratedKeyHolder();
            namedJdbcTemplate.update(sql, params, keyHolder, new String[]{idColumn});
            Number key = keyHolder.getKey();
            Map<String, Object> result = new LinkedHashMap<>(data);
            if (key != null) {
                result.put(idColumn, key.longValue());
            }
            return result;
        } else {
            namedJdbcTemplate.update(sql, params);
            return data;
        }
    }

    public int updateByColumn(String table, String idColumn, Object idValue, Map<String, Object> data) {
        Map<String, Object> columns = new LinkedHashMap<>(data);
        columns.remove(idColumn);
        String setClause = columns.keySet().stream().map(c -> c + " = :" + c).collect(Collectors.joining(", "));
        String sql = "UPDATE " + table + " SET " + setClause + " WHERE " + idColumn + " = :__id";

        MapSqlParameterSource params = new MapSqlParameterSource(columns);
        params.addValue("__id", idValue);
        return namedJdbcTemplate.update(sql, params);
    }

    public int deleteByColumn(String table, String column, Object value) {
        return jdbcTemplate.update("DELETE FROM " + table + " WHERE " + column + " = ?", value);
    }

    /** For composite-key link tables: deletes the row matching ALL given key columns. */
    public int deleteByColumns(String table, Map<String, Object> keyColumns) {
        String whereClause = keyColumns.keySet().stream()
                .map(c -> c + " = :" + c)
                .collect(Collectors.joining(" AND "));
        String sql = "DELETE FROM " + table + " WHERE " + whereClause;
        return namedJdbcTemplate.update(sql, new MapSqlParameterSource(keyColumns));
    }
}
