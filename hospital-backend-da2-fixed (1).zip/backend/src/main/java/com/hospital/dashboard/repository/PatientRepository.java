package com.hospital.dashboard.repository;

import com.hospital.dashboard.model.Patient;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;

/** Direct JdbcTemplate access to the PATIENT table (patient_id, first_name, last_name, dob, gender, city, area, pincode). */
@Repository
public class PatientRepository {

    private final JdbcTemplate jdbcTemplate;

    public PatientRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Patient> ROW_MAPPER = (rs, rowNum) -> {
        Patient p = new Patient();
        p.setPatientId(rs.getLong("patient_id"));
        p.setFirstName(rs.getString("first_name"));
        p.setLastName(rs.getString("last_name"));
        p.setDob(rs.getDate("dob") != null ? rs.getDate("dob").toLocalDate() : null);
        p.setGender(rs.getString("gender"));
        p.setCity(rs.getString("city"));
        p.setArea(rs.getString("area"));
        p.setPincode(rs.getString("pincode"));
        return p;
    };

    public List<Patient> findAll() {
        return jdbcTemplate.query("SELECT * FROM patient ORDER BY patient_id", ROW_MAPPER);
    }

    public Optional<Patient> findById(Long id) {
        List<Patient> results = jdbcTemplate.query(
                "SELECT * FROM patient WHERE patient_id = ?", ROW_MAPPER, id);
        return results.stream().findFirst();
    }

    public Patient save(Patient p) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO patient (first_name, last_name, dob, gender, city, area, pincode) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new String[]{"patient_id"});
            ps.setString(1, p.getFirstName());
            ps.setString(2, p.getLastName());
            ps.setDate(3, p.getDob() != null ? java.sql.Date.valueOf(p.getDob()) : null);
            ps.setString(4, p.getGender());
            ps.setString(5, p.getCity());
            ps.setString(6, p.getArea());
            ps.setString(7, p.getPincode());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        if (key != null) {
            p.setPatientId(key.longValue());
        }
        return p;
    }

    public int update(Long id, Patient p) {
        return jdbcTemplate.update(
                "UPDATE patient SET first_name = ?, last_name = ?, dob = ?, gender = ?, city = ?, area = ?, pincode = ? " +
                        "WHERE patient_id = ?",
                p.getFirstName(), p.getLastName(),
                p.getDob() != null ? java.sql.Date.valueOf(p.getDob()) : null,
                p.getGender(), p.getCity(), p.getArea(), p.getPincode(),
                id);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM patient WHERE patient_id = ?", id);
    }
}
