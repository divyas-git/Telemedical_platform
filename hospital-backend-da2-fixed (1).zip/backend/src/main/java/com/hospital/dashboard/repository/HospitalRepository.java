package com.hospital.dashboard.repository;

import com.hospital.dashboard.model.Hospital;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;

/**
 * HOSPITAL table access. The real Oracle column is "name" (not hospital_name)
 * and there is no single "address" column - it's split into street/area/pincode.
 */
@Repository
public class HospitalRepository {

    private final JdbcTemplate jdbcTemplate;

    public HospitalRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String SELECT_ALL =
            "SELECT hospital_id, name, street, area, city, pincode FROM hospital";

    private static final RowMapper<Hospital> ROW_MAPPER = (rs, rowNum) -> {
        Hospital h = new Hospital();
        h.setHospitalId(rs.getLong("hospital_id"));
        h.setHospitalName(rs.getString("name"));
        h.setStreet(rs.getString("street"));
        h.setArea(rs.getString("area"));
        h.setCity(rs.getString("city"));
        h.setPincode(rs.getString("pincode"));
        return h;
    };

    public List<Hospital> findAll() {
        return jdbcTemplate.query(SELECT_ALL + " ORDER BY hospital_id", ROW_MAPPER);
    }

    public Optional<Hospital> findById(Long id) {
        return jdbcTemplate.query(SELECT_ALL + " WHERE hospital_id = ?", ROW_MAPPER, id)
                .stream().findFirst();
    }

    public Hospital save(Hospital h) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO hospital (name, street, area, city, pincode) VALUES (?, ?, ?, ?, ?)",
                    new String[]{"hospital_id"});
            ps.setString(1, h.getHospitalName());
            ps.setString(2, h.getStreet());
            ps.setString(3, h.getArea());
            ps.setString(4, h.getCity());
            ps.setString(5, h.getPincode());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        if (key != null) h.setHospitalId(key.longValue());
        return h;
    }

    public int update(Long id, Hospital h) {
        return jdbcTemplate.update(
                "UPDATE hospital SET name = ?, street = ?, area = ?, city = ?, pincode = ? WHERE hospital_id = ?",
                h.getHospitalName(), h.getStreet(), h.getArea(), h.getCity(), h.getPincode(), id);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM hospital WHERE hospital_id = ?", id);
    }
}
