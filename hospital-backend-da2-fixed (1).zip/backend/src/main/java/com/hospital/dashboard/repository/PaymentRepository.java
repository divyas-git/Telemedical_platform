package com.hospital.dashboard.repository;

import com.hospital.dashboard.model.Payment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;

/** PAYMENT table access. Real Oracle columns are payment_amount and paid_by -
 *  there is no payment_date or payment_status column. */
@Repository
public class PaymentRepository {

    private final JdbcTemplate jdbcTemplate;

    public PaymentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String SELECT_ALL =
            "SELECT payment_id, consultation_id, payment_amount, paid_by FROM payment";

    private static final RowMapper<Payment> ROW_MAPPER = (rs, rowNum) -> {
        Payment p = new Payment();
        p.setPaymentId(rs.getLong("payment_id"));
        p.setConsultationId(rs.getLong("consultation_id"));
        p.setAmount(rs.getBigDecimal("payment_amount"));
        p.setPaidBy(rs.getString("paid_by"));
        return p;
    };

    public List<Payment> findAll() {
        return jdbcTemplate.query(SELECT_ALL + " ORDER BY payment_id", ROW_MAPPER);
    }

    public Optional<Payment> findById(Long id) {
        return jdbcTemplate.query(SELECT_ALL + " WHERE payment_id = ?", ROW_MAPPER, id)
                .stream().findFirst();
    }

    public Payment save(Payment p) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO payment (consultation_id, payment_amount, paid_by) VALUES (?, ?, ?)",
                    new String[]{"payment_id"});
            ps.setLong(1, p.getConsultationId());
            ps.setBigDecimal(2, p.getAmount());
            ps.setString(3, p.getPaidBy());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        if (key != null) p.setPaymentId(key.longValue());
        return p;
    }

    public int update(Long id, Payment p) {
        return jdbcTemplate.update(
                "UPDATE payment SET consultation_id = ?, payment_amount = ?, paid_by = ? WHERE payment_id = ?",
                p.getConsultationId(), p.getAmount(), p.getPaidBy(), id);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM payment WHERE payment_id = ?", id);
    }
}
