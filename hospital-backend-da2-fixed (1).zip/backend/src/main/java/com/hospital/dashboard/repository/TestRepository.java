package com.hospital.dashboard.repository;

import com.hospital.dashboard.model.MedicalTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;

/** Access to the TEST table (test_id, test_name, test_type - no cost). Java class name
 *  MedicalTest to avoid clashing with JUnit's Test. */
@Repository
public class TestRepository {

    private final JdbcTemplate jdbcTemplate;

    public TestRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<MedicalTest> ROW_MAPPER = (rs, rowNum) -> {
        MedicalTest t = new MedicalTest();
        t.setTestId(rs.getLong("test_id"));
        t.setTestName(rs.getString("test_name"));
        t.setTestType(rs.getString("test_type"));
        return t;
    };

    public List<MedicalTest> findAll() {
        return jdbcTemplate.query("SELECT * FROM test ORDER BY test_id", ROW_MAPPER);
    }

    public Optional<MedicalTest> findById(Long id) {
        return jdbcTemplate.query("SELECT * FROM test WHERE test_id = ?", ROW_MAPPER, id)
                .stream().findFirst();
    }

    public MedicalTest save(MedicalTest t) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO test (test_name, test_type) VALUES (?, ?)",
                    new String[]{"test_id"});
            ps.setString(1, t.getTestName());
            ps.setString(2, t.getTestType());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        if (key != null) t.setTestId(key.longValue());
        return t;
    }

    public int update(Long id, MedicalTest t) {
        return jdbcTemplate.update(
                "UPDATE test SET test_name = ?, test_type = ? WHERE test_id = ?",
                t.getTestName(), t.getTestType(), id);
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update("DELETE FROM test WHERE test_id = ?", id);
    }
}
